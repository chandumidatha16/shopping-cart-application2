import React from "react";
import "./product.css";
import  {Button, Snackbar,Alert, Badge, CardActionArea, CardMedia}  from "@mui/material";
import{MenuItem,TextField,Card,Grid} from "@mui/material";
import{Link} from "react-router-dom"
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import PauseIcon from '@mui/icons-material/Pause';
import Carousel from 'react-material-ui-carousel'
import { Compare } from "@mui/icons-material";

// import { Carousel } from 'react-responsive-carousel';
// import { display } from "@mui/system";
// import data from "./component/back/data/data";

const Products=({productItems,handleAddProduct,handleRemove,handlewishlist,handleInformation,hide,handleFilter,handleFilters,handlesearch,handleCompare,handleClose,snack,handleMultiComp,compare})=>{
   
       var items=[
            {image:"./pics/glass.jpg"
            ,name:"glasses" }, 
        {image:"https://digitalcontent.api.tesco.com/v2/media/ghs/fea96111-a62e-4602-becd-d674459ef4f9/snapshotimagehandler_851786012.jpeg?h=540&w=540",
          name:"redmi"},
        {image:"./pics/samsunglaptop.jpg",
          name:"samsunglaptop"}
    ]

    
    return(
        <div  style={{backgroundColor:"rgb(124, 162, 183)"}}>
       
    <Carousel>
        {items.map(item=>(
            <Grid container justifyContent="center" sx={{marginTop:"20px"}}>
            <Grid item  xs={8} sm={8} md={9} lg={10}>
            <Card sx={{maxWidth:"cover" ,height:"500px"}} >
                <CardActionArea>
                    <CardMedia 
                    
                    component="img"
                    height="40px"
                    image={item.image} 
                    sx={{maxWidth:"auto" ,height:"400px"}}
                    alt={item.name}></CardMedia>
                </CardActionArea>
            </Card>
            </Grid>
            </Grid>
        //    <img style={{marginLeft:"20%",marginTop:"20px",width:"auto",height:"500px",}} src= {item.image} 
        //    alt={item.name}/>

        ))}
    </Carousel>

 <Link to="/compare" style={{textDecoration:"none"}} >
    { compare.length > 0 ?
    <Button variant="contained" color="primary" onClick={()=>handleMultiComp()}  style={{position:"sticky"}}>
        <Badge badgeContent={compare.length <=0 ?"":compare.length} >
             compare 
        </Badge>
    </Button>
    : ""
    }
 </Link>
        <div className="products" >

             
            <div className="filter"style={{marginTop:"40px"}}>
               
            
             
             

           
                </div>  
            {productItems.map((productItem)=>(
                <div >
                
                <div key={productItem.id} className="card">
                    <div  style={{display:"flex",flexDirection:"row",justifyContent:"space-between"}}>
                    <div>available: {productItem.available}</div>
                    <Snackbar anchorOrigin={{vertical:"top",horizontal:"right"}} 
                               open={snack && productItem.available < 1}
                               autoHideDuration={6000}
                               onClose={handleClose}>
                                <Alert onClose={handleClose} 
                                severity="primary">
                                    {productItem.name} 
                                    out of stock</Alert>
                                   
                               </Snackbar>

                    <div> <Button onClick={()=>handlewishlist(productItem)} disabled={hide}> wishlist+</Button></div>
                    
                    </div>
                    
                    
                     <Button  onClick={()=>handleCompare(productItem)}><PauseIcon/> compare</Button>
                      
                        
                    <div >
                        
                    <Link to="/information" ><Carousel><img className="product-image" onClick={()=>handleInformation(productItem)}
                src={productItem.image}
                alt={productItem.name}

                /><img className="product-image" onClick={()=>handleInformation(productItem)}
                src={productItem.image1}
                alt={productItem.name}

                />
                </Carousel></Link> 
                
                </div>
                
                <div>
                    <h3 className="product-name"> product name: {productItem.name}</h3>
                    <div className="product-price">  product price: Rs. {productItem.price}</div>
                   
                    <div className="functions" style={{}}> 
                    
                    <div><Button variant="contained" color="primary" className="cart-items-add" onClick={()=>handleRemove(productItem,1)}>+</Button></div>
                     <div className="">{ productItem.amount}</div>
                    
                        <div className="removebutton"><Button  variant="contained" color="primary" className="cart-items-remove" onClick={()=>handleRemove(productItem,-1)}>-</Button> </div>
                        </div>  
                    
                    <div className="addbutton"  style={{marginTop:"3px",marginLeft:"5px",marginBottom:"50px"}}><Button style={{height:"40px", width:"150px"}} variant="contained" size="small" color="primary" className="product-add-button" onClick={()=>handleAddProduct(productItem,1)}>add to cart</Button></div>
                    
                </div>
                </div>
                </div>
            ))}
        </div>
     </div>  
       
    )
}
export default Products;