import { Button, Grid } from "@mui/material";
// import { useHistory } from "react-router-dom";

import React from "react";

const Wishlist = ({
  whishlist,
  handledelete,
  handlebacktocart
}) => {
    //  let history=useHistory();
 
  return (
    <Grid className="cart-items">
      <Grid container xs={12}  className="cart-items-header">wishlist items</Grid>
      
      {whishlist.length === 0 && (
        <Grid item xs={12} className="carItems-empty">no items are added</Grid>
      )}
      
        {whishlist.map((item) => (
          <Grid container key={item.id} className="cart-items-list">
            <Grid item xs={2}>
            <img
              className="cartitems-images"
              src={item.image}
              alt={item.name}
            />
            </Grid>
            <Grid item xs={2.4} className="cart-items-name">{item.name}</Grid>
           
            <Grid item xs={2.4} className="cart-items-price">
              {item.quantity} * {item.price}={item.quantity * item.price}
            </Grid>
            <Grid item xs={2.4}>
              {" "}
              <Button
                style={{ color: "primary", marginLeft: "20px" }}
                onClick={() => handledelete(item.id)}
              >
                {" "}
                delete
              </Button>
           </Grid>
           <Grid item xs={2.6}>
              {" "}
              <Button
                style={{ color: "primary", marginLeft: "20px" }}
                onClick={()=>handlebacktocart(item)
            }
              >
                {" "}
                back to cart
              </Button>
              
            </Grid>
          </Grid>
        ))}
      
     
    </Grid>
  );
};
export default Wishlist;
