import react from "react"
import { useState } from "react";
// import { auth } from "../back/data/firebase";
const Home=()=>{
    const[initInfo,setInitInfo]=useState({
        email:"",
        password:""
    })
    const{email,password}=initInfo;
    const handler=(e)=>{
        setInitInfo({ ...initInfo,[e.target.name]:e.target.value})
    }
    const signin=(e)=>{
      e.preventDefault();
      auth.signInWithEmailAndPassword(email,password).then(user=>console.log(user)).catch(err=>console.log(err))
        
    }
    const signup=(e)=>{
        e.preventDefault();  
        auth.createUserWithEmailAndPassword(email,password).then(user=>console.log(user)).catch(err=>console.log(err))
    }
return(

    <>
    <center>
    <form autoComplete="off">
    <input type="email" value={email} name="email" onChange={handler} placeholder="email"/><br/>
    <input type="password" value={password} name="password" onChange={handler} placeholder="password"/><br/>
    <button onClick={signin}>sign in</button><br/>
    <button onClick={signup}>sign up</button>
    </form>
    </center>
    </>
)
}
export default Home;

