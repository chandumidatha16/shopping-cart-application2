import { Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";

// import{Table,TableRow,TableBody,TableHead,TableCell}from "@mui/material"

export default function DisplayData({carItems,finalData}){
    
    
      console.log('order page: ',carItems)                  
    
    return(
        
        
        <div> 
           
            {console.log(carItems)}
          
          <bold> <h3 style={{color:"green"}}>congragulations order placed</h3></bold> 
        <div>
          {carItems.map((item)=>(
            <div>
                <img style={{height:"100px",width:"auto"}} src={item.image}
                alt={item.name}/>
                <div>
                <div> price:{item.price}</div>
                </div>
            </div>
            
          ))}
             </div> 
             <Table>
              <TableHead>
                <TableRow>
                <TableCell> firstName</TableCell>
                <TableCell> lastname</TableCell>
                <TableCell>phonenumber</TableCell>
                <TableCell>email</TableCell>
                <TableCell>state</TableCell>
                <TableCell>district</TableCell>
                <TableCell>village</TableCell>
                <TableCell>pincode</TableCell>
                <TableCell>landmark</TableCell>
                <TableCell>paymentmethod</TableCell>
                </TableRow>

              </TableHead>
          {finalData.map((contact)=>(
                    
                    <TableBody> 
                      <TableRow>
                       <TableCell> {contact.firstName}</TableCell> 
                       <TableCell>{contact.lastName}</TableCell>
                                             
                        <TableCell>{contact.phoneNumber}</TableCell>
                       <TableCell> {contact.email}</TableCell>
                       <TableCell> {contact.state}</TableCell>
                       <TableCell> {contact.district}</TableCell>
                       <TableCell> {contact.village}</TableCell>
                        
                       <TableCell> {contact.email}</TableCell>
                        <TableCell> {contact.landmark}</TableCell>
                      <TableCell> {contact.paymentmethod}</TableCell> 
                      </TableRow> 
                      
                      
                       </TableBody>
                      
                       ))}
                    </Table>   
                  
                    
               

        </div>
    )
}