// import React from "react";
// import {useState } from "react";
// import Sstepper from "./stepper";
// export const multiStepContext=React.createContext();

// const StepContext=(productItems,carItems)=>{
   

//     }
//     return(
//         <div>
//             <multiStepContext.Provider value={{currentStep,setStep,userData,setUserData,finalData,setFinalData,submitData,carItems}}>
//                 <Sstepper/>
//             </multiStepContext.Provider>
//         </div>
//     )

// }
// export default StepContext;