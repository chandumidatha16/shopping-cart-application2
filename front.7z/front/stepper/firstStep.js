// import {useState}from "react";
import{Button,TextField}from "@mui/material"



export default function FirstStep({setStep,userData,setUserData}){
    // const [formErrors,setFormErrors]=useState({});
    // const[isSubmit,setIsSubmit]=useState(false);

   
    // const handleSubmit=(e)=>{
    //     e.preventDefault();
    //     setFormErrors(validate(userData));
    //     setIsSubmit(true);

    // }
    // useEffect(()=>{
    //     if(Object.keys(formErrors).length===0 && isSubmit){
    //         console.log(userData)
    //     }
    // });
    // const validate=(values)=>{
    //     const errors={};
    //     // const regex='^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+.[a-zA-Z]$';
    //     if(!values.firstName){
    //         errors.firstName="username is required"
    //     }
    //     if(!values.lastName){
    //         errors.lastName="lastname is required"
    //     }
    //     if(!values.phoneNumber){
    //         errors.phoneNumber="phoneNumber is required"
    //     }
    //     if(!values.email){
    //         errors.email="email is required"
    //     }
    //     return errors
    // }
    
    return(
        <div className="formStyle" style={{display:"flex",justifyContent:"center",margin:"50px"}}>
            <form >
              <div>
             
              <TextField label="firstName"required="required" type="text"  value={userData["firstName"]} onChange={(e)=>setUserData({...userData,"firstName":e.target.value})}/>
              
              
              </div>
               
               <div>
               <TextField label="lastName"required="required" value={userData["lastName"]}onChange={(e)=>setUserData({...userData,"lastName":e.target.value})}/>
              
              </div>
             
               <div>
               <TextField label="phoneNumber"required="required" value={userData["phoneNumber"]} onChange={(e)=>setUserData({...userData,"phoneNumber":e.target.value})}/>
               
               </div>
               <div>
               <TextField label="email" required="required"value={userData["email"]} onChange={(e)=>setUserData({...userData,"email":e.target.value})}/>
              
               </div>
             
               <div>
               <Button onClick={()=>setStep(2)} >Next</Button>
               </div>
                  </form>
               </div>
           )
}