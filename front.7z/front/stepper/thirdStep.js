import { TextField,Button ,FormControl,FormLabel,RadioGroup,FormControlLabel,Radio} from "@mui/material";


export default function ThirdStep({setStep,userData,setUserData,submitData}){
    
    return(
        
                   <div style={{display:"flex",justifyContent:"center", margin:"50px"}}>
                    <form>
                   <div>
                   <TextField label="pincode"value={userData["pincode"]}onChange={(e)=>setUserData({...userData,"pincode":e.target.value})} required/>
                   </div>
                   <div>
                   <TextField label="landmark"value={userData["landmark"]}onChange={(e)=>setUserData({...userData,"landmark":e.target.value})} required/>
                   </div>
                   <div>
                   <FormControl>
      <FormLabel id="demo-controlled-radio-buttons-group">choose payment</FormLabel>
      <RadioGroup
        aria-labelledby="demo-controlled-radio-buttons-group"
        name="controlled-radio-buttons-group"
        value={userData["payment method"]}
        onChange={(e)=>setUserData({...userData,"paymentmethod":e.target.value})}
      
      required>
        <FormControlLabel value="cash on delivery" control={<Radio />} label="cash on delivery" />
        <FormControlLabel value="pay through UPI" control={<Radio />} label="UPI" />
        
      </RadioGroup>
    </FormControl>
    </div>
    <div> <Button onClick={()=>setStep(2)}>back</Button>
                   <Button onClick={submitData}>submit</Button>
                   </div>

                   </form>
                   </div>

    )
}