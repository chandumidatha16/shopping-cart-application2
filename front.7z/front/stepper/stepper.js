
import FirstStep from"./firstStep";
import SecondStep from"./secondStep";
import ThirdStep from"./thirdStep";
import{Stepper,StepLabel,Step}from"@mui/material";
import { useState } from "react";

import DisplayData from"./display";



 

function Sstepper({carItems,productItems}) {
 
  const[currentStep,setStep]=useState(1);
  const[userData,setUserData]=useState([]);
  const[finalData,setFinalData]=useState([]);
   
  function submitData(){
      setFinalData(finalData=>[userData])
      setUserData("");
      setStep(-1);
  }
  function showStep(step){
    switch(step){
      case 1:
        return<FirstStep setStep={setStep}
        userData={userData}
        setUserData={setUserData}/>
      case 2:
        return<SecondStep setStep={setStep}
        userData={userData}
        setUserData={setUserData}/>
        case 3:
          return<ThirdStep setStep={setStep}
          userData={userData}
          setUserData={setUserData}
          submitData={submitData}/>
    
      default:return "unknownStep";
    }
   
    
  }
  
  return (
    <div className="App">
      
      <Stepper activeStep={currentStep-1}>
        <Step>
          <StepLabel>customer Details</StepLabel>
        </Step>
        <Step>
          <StepLabel>Address Part</StepLabel>
        </Step>
        <Step>
          <StepLabel>payment details  </StepLabel>
          
        </Step>
        
        
        
      </Stepper>
      
      
      {showStep(currentStep)}
      <br></br>
      {finalData.length>0?<DisplayData carItems={carItems} finalData={finalData}/>:""}
          
        
      
      
    
    
    
    

       
      
      </div>
      
      
    
  );
}

export default Sstepper;
