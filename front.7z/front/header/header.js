
import {Link} from "react-router-dom";
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import HomeIcon from '@mui/icons-material/Home';
import Badge from '@mui/material/Badge';


 import"./header.css";
import { TextField,Grid,MenuItem,Button, Typography } from "@mui/material";
const Header=({carItems,whishlist,handleFilter,handleFilters,handlesearch})=>{
    return(
        <header className="header">
           <Grid container direction="row" spacing={2} justifyContent="center">
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
        <Grid container>
        <Grid item xs={6}>

          
                <Typography>
                    <Link to="/" className="logo" >flipkart</Link>
                </Typography>
            
            </Grid>
            </Grid>

        </Grid>
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
        <Grid container direction="row" justifyContent="center" sx={{marginTop:"10px"}} >
         <Grid item xs={10} sm={10} md={10} lg={10 }>   <TextField fullWidth   type="text" onChange={(e)=>handlesearch(e)} placeholder="search here..." ></TextField></Grid>
         <Grid item xs={2} sm={2} md={2} lg={2}>
            <TextField select fullWidth>
                <MenuItem><Button className="filters" onClick={()=>handleFilter("laptops")}>laptops</Button></MenuItem>
                <MenuItem><Button className="filters" onClick={()=>handleFilter("mobiles")}>mobiles</Button></MenuItem>
                <MenuItem><Button className="filters" onClick={()=>handleFilter("pens")}>pens</Button></MenuItem>
                <MenuItem><Button className="filters" onClick={()=>handleFilter("glases")}>glases</Button></MenuItem>
                <MenuItem><Button className="filters" onClick={()=>handleFilters()}>all</Button></MenuItem>
           </TextField>
           </Grid>
</Grid>

        </Grid>
        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}   className="headerlinks">
            

            <Grid container >
            <Grid item sx={4}>
            <ul>
                <li>
                    <Link to="/" >< HomeIcon/></Link>
                </li>
            </ul>
            </Grid>
            <Grid item sx={4}>
            <ul>
                <li>
                    <Link to="/cart" ><Badge badgeContent={carItems.length <=0 ?"":carItems.length} ><ShoppingCartIcon/></Badge></Link>
                </li>
            </ul>
            </Grid>
            <Grid item sx={4}>
            <ul>
                <li>
                    <Link to="/whishlist"><Badge badgeContent={whishlist.length <=0 ?"":whishlist.length}><FavoriteBorderIcon/></Badge></Link>
                </li>
            </ul>
            </Grid>
            </Grid>
        </Grid>
        </Grid> 
       </header> 
    )
}
export default Header;