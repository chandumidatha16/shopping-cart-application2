import { Rating ,Button} from "@mui/material";
import react from "react";
const Compare=({compare,handlesearch,productItems,rCompare,handleGo,handleChange,handleDlt})=>{
    console.log(compare)
    return(
        <div>
        
        <bold style={{color:"black",marginLeft:"120px",fontSize:"50px"}}>comparing</bold>
        <div  style={{display:"flex",flexDirection:"row",justifyContent:"center",border:"1px solid skyblue" }}>
                {rCompare.map((item)=>(
                
               <div key={item.id} style={{border:"1px solid black",width:"260px"}} >
                <Button onClick={()=>handleDlt(item.id)}>remove</Button>
                <div  ><img    style={{width:"250px", marginTop:"50px"}} src={item.image}
                alt={item.name}/></div>
                <div> product:{item.name}</div>
                <div> price:{item.price}/- Rs</div>
                <div> Rating:<Rating
        
        value={item.rating}
        onChange={(event,newValue)=>handleChange(item,newValue)}
        precision="0.5"
        
      /></div>
                <div> product info:{item.information}</div>
                 </div>
                 
                ))}
               
               </div> 
             
               </div>
        
      
        
    )
}
export default Compare;