// import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
// import { MapInteractionCSS } from 'react-map-interaction';


import { Button, TextField, Typography } from '@mui/material';
import {useHistory} from "react-router-dom"
import ReplyIcon from '@mui/icons-material/Reply';
import Rating from '@mui/material/Rating';
// import data from '../../back/data/data';
import { useState } from 'react';
import Carousel from 'react-material-ui-carousel';
 

const Information=({information,setInformation,setProductItems,productItems})=>{
  const[comment,setComment]=useState(information.comment);
  console.log(information);
    let history=useHistory();
    const handlediscount=(item)=>{
      let temp=[...productItems];
      let x=temp.indexOf(item);
      let y =Math.round(Math.random()*10)
      let z=(temp[x].price*y)/100;
      temp[x].discount=z;
      // setDisc(100-y);
      setProductItems(information.price-temp); 
    
       }
       const handleChange=( item,rate)=>{
        let temp=[...productItems];
        let disp =temp.indexOf(item);
        temp[disp].rating=rate;
        // setInformation(temp)
        setProductItems(temp)
        
          
    
      }
      const handleComment=(event)=>{
         if(event.target.value!==""){
          let comm=event.target.value;
          setComment(comm)
          
         }
         if(event.target.value===""){
          
          
          alert("enter your comment")
         }
      }
    return(
        <div> 
            <div style={{ fontSize:"40px",fontFamily:"fantasy"}}>
            information
            </div>
            <div style={{display:"flex",flex:"wrap",flexDirection:"row"}}>
            <Button onClick={()=>history.push("/")}><ReplyIcon/></Button>
            
         
            
                
                    <div style={{width:"400px",height:"400px",marginBottom:"0px"
                        
                       
                    }}>
                   
                    <Carousel>
                    <img style={{width:"400px",height:"400px"}}
                    src={information.image}
                    alt={information.name} /> 
                    <img style={{width:"400px",height:"400px"}}
                    src={information.image1}
                    alt={information.name} /> 
                  
                  </Carousel>            
                       
                    </div>
                   
                    <div style={{marginTop:"10px",height:"400px",width:"700px",marginLeft:"20%",marginTop:"100px"}}>
                    <p style={{}}> Rating: <Rating
        
        value={information.rating}
        onChange={(event,newValue)=>handleChange(information,newValue)}
        precision="0.5"
        
      /></p>
      <Typography>
      <Button style={{color:"blue"}} onClick={()=>handlediscount(information)}> discount</Button>
      <Typography>upto {information.discount} % discount</Typography>
      </Typography>
                    <p style={{fontSize:"20px"}}>Product Name: <b>{information.name}</b></p>
                   <div style={{fontSize:"20px"}}><p style={{fontSize:"20px",marginTop:"10px" ,color:"blue"}}> <b style={{color:"black"}}> price:</b> {Math.round(information.price-information.discount)} /- Rs</p></div>
                <div style={{fontSize:"20px",marginTop:"10px"}}> <b style={{color:"black"}}>ABOUT : </b> {information.information}</div>
                <div><form onSubmit={(event)=>handleComment(event)}><TextField value={comment["comments"]} onChange={(event)=>setComment({...comment,"comments":event.target.value})} placeholder="enter comment...."/><Button type='submit'> send</Button></form></div>
                <div><Button onClick={()=>history.push("/stepper")}>Buy it now</Button></div>
                </div>
         </div>
        </div>

    )

}
export default Information;