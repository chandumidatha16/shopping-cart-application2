
import { Route, Switch } from "react-router-dom";
// import Switch from "react-switch";

import Products from "../product/product";
import Cart from "../cart/cart";
import Wishlist from "../whishlist/whishlist";
import Information from "../information/information";

import SStepper from "../stepper/stepper";
import Compare from "../compare/compare";
// import StepContext from " ../stepper/stepContext"


const RoutesAll = ({
  productItems,
  carItems,
  handleAddProduct,
  
  handleRemove,
  handleClear,
  handleDelete,
  handlewishlist,
  whishlist,
  handledelete,
  handlebacktocart,
  handleInformation,
  information,
  setInformation,
  setProductItems,
  handleFilter,
  handleFilters,
  handleChange,
  value,
  handlesearch,
  handlediscount,
  submitData,setHide
  ,hide,
  handleCompare,
  compare,
  handleSearch,rCompare,
  handleGo,handleClose,
  snack,handleMultiComp,
  handleDlt
  
  
  // disabled,
}) => {
  return (
    <div>
     <Switch>
      <Route path="/" exact>
          <Products
            
            handleMultiComp={handleMultiComp}
            productItems={productItems}
            handleAddProduct={handleAddProduct}
            handleRemove={handleRemove}
            // handleAddQuantity = {handleAddQuantity}
            // handleRemoveQuantity={handleRemoveQuantity}
            handlewishlist={handlewishlist}
            handleInformation={handleInformation}
            setProductItems={setProductItems}
            handleFilter={handleFilter}
            handleFilters={handleFilters}
            setHide={setHide}
            hide={hide}
            whishlist={whishlist}
            handlesearch={handlesearch}
            handleCompare={handleCompare}
            handleClose={handleClose}
            snack={snack}
            compare={compare}
            
            // disabled={disabled}
           
          />
       </Route >
       <Route path="/cart" exact>
          <Cart
            carItems={carItems}
             handleAddProduct={handleAddProduct}
             handleRemove={handleRemove}
            // handleAddQuantity = {handleAddQuantity}
            // handleRemoveQuantity={handleRemoveQuantity}
            handleClear={handleClear}
            handleDelete={handleDelete}
          />
        </Route>
        <Route path="/whishlist" exact>
          <Wishlist   
          whishlist={whishlist}
          handledelete={handledelete}
          handlebacktocart={handlebacktocart}/>

          

        </Route>
        <Route path="/information" exact>
          <Information 
           
           information={information}
           setInformation={setInformation}
           handleChange={handleChange}
           productItems={productItems}
           handlediscount={handlediscount}
           setProductItems={setProductItems}
          
           value={value}/>
        </Route>
           
        <Route path="/stepper" exact>
      
        
    <SStepper 
     carItems={carItems}
    productItems={productItems}
    submitData={submitData}
    />
   
       
        </Route>
        <Route path="/compare" exact>
      
        
    <Compare 
    handleDlt={handleDlt}
    compare={compare}
    handlesearch={handlesearch}
    rCompare={rCompare}
    productItems={productItems}
    handleGo={handleGo}
     
    />
   
       
        </Route>
       
       
      </Switch>
    </div>
  );
};
export default RoutesAll;
