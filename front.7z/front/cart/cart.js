import { Button, Grid } from "@mui/material";

import React from "react";
import { useHistory } from "react-router-dom";
import "./cart.css";
const Cart = ({
  carItems,
   handleAddProduct,
//   handleAdd,
  handleRemove,
  handleClear,
  handleDelete,
}) => {
  const totalprice = carItems.reduce(
    (price, carItem) => price + carItem.amount * carItem.price,
    0
  );
  const history=useHistory();

  return (
    <Grid container xs={12}  direction="row" width="75%" className="cart-items">
      <Grid container xs={12} className="cart-items-header">cart items</Grid>
      <Grid container borderBottom="2px solid black">
      <Grid item xs={12} className="clear-cart-name">
        {carItems.length >= 1 && (
          <Button style={{ color:"primary",variant:"contained"}}className="clear-cart" onClick={handleClear}>
            clear items
          </Button>
        )}
      </Grid>
     
      {carItems.length === 0 && (
        <Grid item xs={12} className="carItems-empty">no items are added</Grid>
      )}
     
     
      <Grid item xs={12}>
        {carItems.map((item) => (
          <Grid container key={item.id} direction="row" className="cart-items-list">
           <Grid item xs={2.4}>
            <img
              className="cartitems-images"
              src={item.image}
              alt={item.name}
            />
            </Grid>
            <Grid item xs={2.4} className="cart-items-name">{item.name}</Grid>
            <Grid item xs={2.4} className="cart-items-function">
              
              <Button style={{ color:"primary",variant:"contained"}}
                className="cart-items-add"
                onClick={() => handleRemove(item,1)}
              >
                +
              </Button>

              <Button style={{ color:"primary",variant:"contained"}}
                className="cart-items-remove"
                onClick={() => handleRemove(item,-1)}
              >
                -
              </Button>
            </Grid>
            <Grid item xs={2.4} className="cart-items-price">
              {item.amount} * {item.price}={item.amount * item.price}
            </Grid>
            <Grid item xs={2.4}>
              {" "}
              <Button
                style={{ color: "primary", marginLeft: "20px",  variant:"contained" }}
                onClick={() => handleDelete(item.id)}
              >
                {" "}
                delete
              </Button>
            </Grid>
          </Grid>
        ))}
         </Grid>
        </Grid>
      
       <Grid item xs={12}>
      <Grid container   className="cart-items-total-name">
        <Grid item xs={6}>
        total price
        </Grid>
        <Grid item  xs={3} className="cart-items-total-price"> Rs.{totalprice}</Grid>
        <Grid  item xs={ 3} ><Button style={{ marginBottom:"50px"}} variant="outlined" onClick={()=>history.push("/stepper")}> buy it now</Button></Grid>
      </Grid>
      </Grid>
      
   
    </Grid>
  );
};
export default Cart;
